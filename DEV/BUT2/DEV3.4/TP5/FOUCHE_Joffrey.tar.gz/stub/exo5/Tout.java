import java.util.*;

/*public class Tout{
    public void plusGrand(Person p){
        ArrayList<Person> pile = new ArrayList<Person>();
        pile.add(p);
        ArrayList<Person> liste = new ArrayList<Person>();
        for(int i=0;!pile.isEmpty();i++){
            Person temp =pile.remove();
            //ArrayList<Person> file = temp.getListe();
            //pile.add(file.remove());
            liste.add(temp);
        }
    }
}*/