//Fouché Joffrey

public interface Ensemble {
    public boolean ajouter(int element);
}
