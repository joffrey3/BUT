package com.example.fouche_1_disposition;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

//Exercice 3
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView x = findViewById(R.id.xValue);
        TextView x = findViewById(R.id.xValue);
    }
}